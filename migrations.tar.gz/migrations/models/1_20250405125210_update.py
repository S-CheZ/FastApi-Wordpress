from tortoise import BaseDBAsyncClient


async def upgrade(db: BaseDBAsyncClient) -> str:
    return """
        CREATE TABLE IF NOT EXISTS `category` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `name` LONGTEXT NOT NULL
) CHARACTER SET utf8mb4;
        CREATE TABLE IF NOT EXISTS `notelist` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `title` LONGTEXT NOT NULL,
    `content` LONGTEXT NOT NULL,
    `category_id` INT NOT NULL,
    CONSTRAINT `fk_notelist_category_090b11a9` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE CASCADE
) CHARACTER SET utf8mb4;"""


async def downgrade(db: BaseDBAsyncClient) -> str:
    return """
        DROP TABLE IF EXISTS `category`;
        DROP TABLE IF EXISTS `notelist`;"""
