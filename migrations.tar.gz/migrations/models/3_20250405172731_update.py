from tortoise import BaseDBAsyncClient


async def upgrade(db: BaseDBAsyncClient) -> str:
    return """
        # ALTER TABLE `user` ADD `avatar_img` VARCHAR(50);
        # ALTER TABLE `notelist` ADD `user_id` INT NOT NULL;
        # ALTER TABLE `notelist` ADD CONSTRAINT `fk_notelist_user_bb4cd61b` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;"""


async def downgrade(db: BaseDBAsyncClient) -> str:
    return """
        ALTER TABLE `notelist` DROP FOREIGN KEY `fk_notelist_user_bb4cd61b`;
        ALTER TABLE `user` DROP COLUMN `avatar_img`;
        ALTER TABLE `notelist` DROP COLUMN `user_id`;"""
